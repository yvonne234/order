import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receive-transaction',
  templateUrl: './receive-transaction.component.html',
  styleUrls: ['./receive-transaction.component.css']
})
export class ReceiveTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
