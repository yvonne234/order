export class Card{
    constructor(public type: string){}
}