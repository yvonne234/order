export class JobsProfiles{
    constructor(public id: number, public jobTitle?: string, public skills?: string){}
}